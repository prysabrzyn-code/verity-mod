# Abandoned factory map. Run as a player standing where the factory should start.
# Footprint: 12 wide (x), 24 long (z), 4 high (y).

# Floor and ceiling
fill ~-1 ~-1 ~-1 ~12 ~-1 ~24 minecraft:stone_bricks
fill ~-1 ~4 ~-1 ~12 ~4 ~24 minecraft:stone_bricks

# Outer walls (hollow shell)
fill ~-1 ~ ~-1 ~12 ~3 ~24 minecraft:stone_bricks hollow

# Clear the inside
fill ~ ~ ~ ~11 ~3 ~23 minecraft:air

# Dividing wall between storage (front) and control room (back)
fill ~ ~ ~12 ~11 ~3 ~12 minecraft:stone_bricks
fill ~5 ~ ~12 ~6 ~2 ~12 minecraft:air

# Storage room: dusty crates with keys (chests, empty for now)
setblock ~2 ~ ~2 minecraft:chest[facing=north]
setblock ~4 ~ ~2 minecraft:chest[facing=north]
setblock ~9 ~ ~2 minecraft:barrel[facing=up]

# Unlit lamps on the ceiling
setblock ~2 ~3 ~2 minecraft:redstone_lamp
setblock ~9 ~3 ~2 minecraft:redstone_lamp
setblock ~2 ~3 ~9 minecraft:redstone_lamp
setblock ~9 ~3 ~9 minecraft:redstone_lamp

# Control room: dead monitors (dark furnaces stand in for screens)
setblock ~3 ~ ~18 minecraft:furnace[facing=south]
setblock ~8 ~ ~18 minecraft:furnace[facing=south]
setblock ~3 ~3 ~20 minecraft:redstone_lamp

# Exit door at the far end (lower and upper halves)
setblock ~6 ~ ~23 minecraft:iron_door[half=lower,facing=south,hinge=left]
setblock ~6 ~1 ~23 minecraft:iron_door[half=upper,facing=south,hinge=left]

say Factory built. Run /function verity_map:summon when you are ready.
