# Spawns a Gloomkin near the exit door of the factory.
# Run this when the player is inside the factory (the mob appears at the player's position).
summon verity:gloomkin ~ ~ ~
say A Gloomkin has appeared.
